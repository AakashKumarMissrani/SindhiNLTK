class SindhiStopwords:
    def __init__(self):
        self.stopwords = {"۽", "يا", "پر", "ڪرڻ", "ته", "کي", "جو", "جي", "جا", "تي", "تان", "کان", "۾", "سان", "آهي", "آهن"}
    def remove_stopwords(self, tokens):
        return [t for t in tokens if t not in self.stopwords]