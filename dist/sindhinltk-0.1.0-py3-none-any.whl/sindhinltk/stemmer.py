class SindhiStemmer:
    def __init__(self):
        self.suffixes = ['ائيندڙ', 'يندڙ', 'يائين', 'ائين', 'يون', 'ان', 'ون', 'ين', 'ي', 'و']
    def stem(self, word: str) -> str:
        for s in self.suffixes:
            if word.endswith(s) and len(word) - len(s) >= 2: return word[:-len(s)]
        return word