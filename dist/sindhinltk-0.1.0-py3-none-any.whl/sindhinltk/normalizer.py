import unicodedata
import re

class SindhiNormalizer:
    def __init__(self):
        self.ZERO_WIDTH = ['\u200C', '\u200D', '\u200B', '\uFEFF', '\u00AD']
    def normalize(self, text: str) -> str:
        text = unicodedata.normalize('NFC', text)
        for zw in self.ZERO_WIDTH:
            text = text.replace(zw, '')
        return re.sub(r'[ \t]+', ' ', text).strip()