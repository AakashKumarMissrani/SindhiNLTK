import unicodedata
import re
class SindhiNormalizer:
    def normalize(self, text):
        # Normalize to NFKC to align with Transformer expectations
        text = unicodedata.normalize('NFKC', text)
        # Remove multiple spaces/tabs
        return re.sub(r'[ \t]+', ' ', text).strip()